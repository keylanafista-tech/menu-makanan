#include <iostream>
#include <stdlib.h>
using namespace std;

int main()
{
    int pilih, jumlah;
    int total = 0;
    int bayar, kembali;
    char ulang;

    int jml1 = 0, jml2 = 0, jml3 = 0, jml4 = 0, jml5 = 0, jml6 = 0;

    int harga1 = 15000;   
    int harga2 = 13000;
    int harga3 = 18000;   
    int harga4 = 16000;   
    int harga5 = 5000;    
    int harga6 = 7000;    

    do
    {
        system("cls");
        cout << "================================" << endl;
        cout << "      WARUNG MAKAN SEJAHTERA    " << endl;
        cout << "================================" << endl;
        cout << "1. Nasi Goreng   Rp 15000" << endl;
        cout << "2. Mie Goreng    Rp 13000" << endl;
        cout << "3. Ayam Geprek   Rp 18000" << endl;
        cout << "4. Soto Ayam     Rp 16000" << endl;
        cout << "5. Es Teh        Rp 5000" << endl;
        cout << "6. Es Jeruk      Rp 7000" << endl;
        cout << "================================" << endl;

        cout << "Pilih menu (1-6) : ";
        cin >> pilih;

        if (pilih < 1 || pilih > 6)
        {
            cout << "Menu tidak ada!" << endl;
        }
        else
        {
            cout << "Jumlah : ";
            cin >> jumlah;

            switch (pilih)
            {
            case 1:
                jml1 = jml1 + jumlah;
                break;
            case 2:
                jml2 = jml2 + jumlah;
                break;
            case 3:
                jml3 = jml3 + jumlah;
                break;
            case 4:
                jml4 = jml4 + jumlah;
                break;
            case 5:
                jml5 = jml5 + jumlah;
                break;
            case 6:
                jml6 = jml6 + jumlah;
                break;
            }
            cout << "Pesanan ditambahkan!" << endl;
        }

        cout << endl;
        cout << "Mau pesan lagi? (y/t) : ";
        cin >> ulang;

    } while (ulang == 'y' || ulang == 'Y');

    total = (jml1 * harga1) + (jml2 * harga2) + (jml3 * harga3) +
            (jml4 * harga4) + (jml5 * harga5) + (jml6 * harga6);

    system("cls");
    cout << "================================" << endl;
    cout << "         STRUK PEMBELIAN        " << endl;
    cout << "================================" << endl;

    if (jml1 > 0)
        cout << "Nasi Goreng  " << jml1 << " x " << harga1 << " = " << jml1 * harga1 << endl;
    if (jml2 > 0)
        cout << "Mie Goreng   " << jml2 << " x " << harga2 << " = " << jml2 * harga2 << endl;
    if (jml3 > 0)
        cout << "Ayam Geprek  " << jml3 << " x " << harga3 << " = " << jml3 * harga3 << endl;
    if (jml4 > 0)
        cout << "Soto Ayam    " << jml4 << " x " << harga4 << " = " << jml4 * harga4 << endl;
    if (jml5 > 0)
        cout << "Es Teh       " << jml5 << " x " << harga5 << " = " << jml5 * harga5 << endl;
    if (jml6 > 0)
        cout << "Es Jeruk     " << jml6 << " x " << harga6 << " = " << jml6 * harga6 << endl;

    cout << "--------------------------------" << endl;
    cout << "Total Bayar : Rp " << total << endl;

    if (total == 0)
    {
        cout << "Kamu belum pesan apa-apa" << endl;
    }
    else
    {
        cout << "Uang Anda   : Rp ";
        cin >> bayar;

        while (bayar < total)
        {
            cout << "Uang kurang! Masukkan lagi : Rp ";
            cin >> bayar;
        }

        kembali = bayar - total;
        cout << "Kembalian   : Rp " << kembali << endl;
    }

    cout << "================================" << endl;
    cout << "   Terima kasih sudah makan :)  " << endl;
    cout << "================================" << endl;

    system("pause");
    return 0;
}
